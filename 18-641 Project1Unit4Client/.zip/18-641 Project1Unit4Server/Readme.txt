There are two projects: server and client
You can first start the server and run a client to interact with server.
Two properties files in client folder are provided for testing.